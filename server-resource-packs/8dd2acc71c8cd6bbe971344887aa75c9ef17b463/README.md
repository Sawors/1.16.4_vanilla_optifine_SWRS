# Magic Resource Pack

This RP is meant for use with the Magic Bukkit plugin:

https://github.com/elBukkit/MagicPlugin/wiki

## RP Credits

- 3D Artists: 
  - Dr00bles (play.potterworldmc.com)
  - Lix3nn (https://sketchfab.com/Lix3nn/models)
- 2D Artists: 
  - Dr00bles
  - Forrest Imel (https://www.unrealengine.com/marketplace/150-fantasy-spell-icons-pack)
  - MutimEndymion
- Sound Effects:
  - Dr00bles
  - S-Toad (Flute samples for Ocarina)
